package com.soft1721.jianyue.api.util;

public class MsgConst {
    public static final String SUCCESS = "请求成功";
    public static final String USER_ID_NO_FOUND = "id不存在";
    public static final String USER_MOBILE_NO_FOUND = "手机号不存在";
    public static final String PASSWORD_ERROR = "密码错误";
    public static final String USER_STATUS_ERROR = "账号异常";
}