package com.soft1721.jianyue.api.entity.dto;

import lombok.Data;

@Data
public class UserDTO {
    private String mobile;
    private String password;
}
